-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jan 09, 2022 at 10:27 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laraveldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2022_01_08_113218_create_user', 1),
(3, '2022_01_08_211734_create_tasks_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iscompleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `timeout` smallint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `task`, `iscompleted`, `created_at`, `start_time`, `end_time`, `timeout`) VALUES
(12, 'cmpwork1', 0, '2022-01-09 07:22:08', '2022-01-09 06:51:00', '2022-01-09 07:00:00', 0),
(11, 'worktime2', 1, '2022-01-09 06:41:37', '2022-01-09 06:11:00', '2022-01-09 06:14:00', 2),
(9, 'worktime1', 1, '2022-01-09 06:04:04', '2022-01-09 11:41:00', '2022-01-09 02:35:00', 0),
(10, 'qaaaaa', 0, '2022-01-09 01:10:50', '2022-01-09 06:41:00', '2022-01-09 23:39:00', 0),
(13, 'testwork', 0, '2022-01-09 08:58:30', '2022-01-09 16:27:00', '2022-01-09 17:30:00', 0),
(14, 'sfdsfdsf', 0, '2022-01-09 10:24:33', '2022-01-09 15:55:00', '2022-01-09 15:57:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `dob` date NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`) USING HASH
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `dob`, `gender`, `remember_token`, `photo`) VALUES
(1, 'Sheeba Kiron', 'sheeba.kiron8@gmail.com', '$2y$10$XD48JJXvTbtTAJ1e9gllUOHOs7pkngqNeS/ROApNVCB3r1SlGH.UO', '2022-01-08 11:27:20', '1994-01-14', 'Female', 'fqBw2dlAQB5p5ZJnxPjjp6yIEzaqDvdRgzt4OuQuSJTDccvc4ohP5ym8D3Eh', 'abv.jpg'),
(2, 'deepa', 'deepa@yahoo.com', '$2y$10$3VRYkW1ue1Pg/NPciO4sae97lKF7pfoq32xI4.iopQnf.RFAkbBc2', '2022-01-08 17:00:55', '1995-05-08', 'Female', 'SZuGneN7texNj3ytHGab4KIMyCzBgYmRiXwu8KyE', 'WhatsApp_Image_2021-10-10_at_12_16_56_PM.jpeg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
