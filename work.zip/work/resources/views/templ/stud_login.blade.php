@include('templ.header')

<div class="container">
  <h2 class="text-center">SignIn</h2>
  <br> 
   <form action = "customLogin" method = "post" class="form-group" style="width:70%; margin-left:15%;" action="/action_page.php">
  @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
 <?php if(isset($msg)){echo '<label class="form-group" style="color:red;">'.$msg.'</label><br>';}?>
  <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>"><input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
 	<label>Email:</label>
    <input type="email" class="form-control" placeholder="Enter Email"   name="email" required>
	<label>Password:</label>
    <input type="password" class="form-control" placeholder="Enter password" name="password"   required>
     
<br>
    <button type="submit"  value = "Add student" class="btn btn-primary">Submit</button>
  </form>
</div>

@include('templ.footer')