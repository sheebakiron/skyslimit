 @include('templ.header')
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Sample page content -->
    <div class="container">
        <h3>Posts</h3>
  <div class="row">
	   <div class="list">
     <?php
	 $i=1;
	 foreach ($data['data']['children'] as $val) 
		   {
			$title = $val['data']['title'];
			$domain = $val['data']['domain'];
			$selftext = $val['data']['selftext'];
			$url = $val['data']['url'];
			//$reddit_link = $val['data']['permalink'];
			$post_id = $val['data']['id'];
			$date = $val['data']['created_utc'];
			$user = $val['data']['author'];
			$img = $val['data']['thumbnail'];
			/*if($val['data']['preview']['images'][0]['source']['url']){
			 $img = $val['data']['preview']['images'][0]['source']['url'];
			 }*/
			//$img=$val['data']['thumbnail']['preview']
			//$flair = $val['data']['author_flair_text'];
			//$up = $val['data']['ups'];
			//$comments = $val['data']['num_comments'];
			//$description = $val['data']['description'];
			//$thumbnail = $val['data']['secure_media']['oembed']['thumbnail_url'];
			if (@getimagesize($img)) {
			$imflag=1;
			} else {
			$imflag=2;
			}
			?>   
	
      <div class="card mb-3">
        <div class="card-body">
          <h5 class="card-title"><?php echo $i;?>)   <?php echo $title;?> </h5>
		  <?php if($imflag==1){?>
			   <p>
               <img title="<?php echo $user;?>" class="img-responsive   blog-inner" src="<?php echo $img;?>">
			   </p>
			   <?php }?>
          <p class="card-text"><b><?php echo $user;?>, <?php echo date("M d , Y",$date);?></b>
		   <?php if(strlen($selftext)>5){?>
				   --<span id="icon<?php echo $post_id;?>" onClick="popin('<?php echo $post_id;?>')"> <?php echo substr($selftext,0,25);?>
				   ...(<a onClick="popin('<?php echo $post_id;?>')" style="color:#FF0000;cursor:pointer;">More</a>)
				  </span>
				  <span id="info<?php echo $post_id;?>" style="display: none" ><?php echo $selftext;?>
				  <br><a onClick="popout('<?php echo $post_id;?>')" style="color:#FF0000;cursor:pointer;">Less</a>
				  </span>
				 <?php }?> 
		  </p>
        </div>
      </div>
      <?php
		 $i++;
		  }
		  ?>  
       </div> 
	   <div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div> 
	    <!--<div class="card mb-3 loadid" >Loading Pages...</div>    -->                                                                          
   </div>
      </div>
	  <script>
 function popin(i) {
  document.getElementById('info'+i).style.display = 'block';
  document.getElementById('icon'+i).style.display = 'none';
}
 function popout(i) {
  document.getElementById('info'+i).style.display = 'none';
  document.getElementById('icon'+i).style.display = 'block';
}
</script> 
	 <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script>
var currentscrollHeight = 0;
var count = 0;
var pagecount = 2;
$(window).on("scroll", function () {

  const scrollHeight = $(document).height();
  const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
  const isBottom = scrollHeight - 100 < scrollPos;
  const list = $(".list");
  
  if (isBottom && currentscrollHeight < scrollHeight) {
//---------------------
$.ajax({url: "indexajax/"+pagecount, success: function(result){
	 list.append(result);
	 // $(".loadid").hide();
  }});
pagecount++;
    currentscrollHeight = scrollHeight;
  }
});
</script>
	 
	   
@include('templ.footer')