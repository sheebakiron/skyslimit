@include('templ.header')
<div class="container">
<div  class="col-md-12">
@include('templ.leftmenu')

<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%">
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%"><h4>View Profile</h4></div>
 @foreach ($users as $user)
      
      <div  class="col-md-3 form-group">Name </div>
      <div class="col-md-9 form-group">{{ $user->name }}</div> 
	  <div class="col-md-3 form-group" >Email </div> 
      <div class="col-md-9 form-group" >{{ $user->email }}</div> 
	  <div  class="col-md-3 form-group">Date Of Birth </div>
      <div  class="col-md-9 form-group">{{ date("d/m/Y",strtotime($user->dob)) }}</div> 
	  <div class="col-md-3 form-group" >Gender </div>
      <div class="col-md-9 form-group" >{{ $user->gender }}</div>
	  <div  class="col-md-3 form-group">Photo </div>
      <div class="col-md-9 form-group"><img src="uploads/{{ $user->photo }}" width="100" height="100" /></div> 
	  
       
      @endforeach
</div>

</div>
</div>
@include('templ.footer')

 