@include('templ.header')
<div class="container">
<div  class="col-md-12">
@include('templ.leftmenu')
<form action="passupdate" method="post" class="form-group"    >
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
 
<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%">
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%"><h4>Reset Password</h4></div>
@if(session()->has('messagechpass'))
    <div class="alert alert-success">
        {{ session()->get('messagechpass') }}
    </div>
@endif
       <div  class="col-md-3 form-group">Password </div>
      <div class="col-md-9 form-group"><input type="password" name="password" pattern="([a-zA-Z0-9]).{8,}" title="Must contain Alphanumeric characters, and at least 8 or more characters" required /></div> 
	  <div class="col-md-12 form-group">
    <button type="submit"  value = "Add student" class="btn btn-primary">Submit</button>
	</div>
 </div>
</form>
</div>
</div>
@include('templ.footer')

 