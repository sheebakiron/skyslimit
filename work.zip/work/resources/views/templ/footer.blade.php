 <footer  class="navbar navbar-default" >
    <div class="container text-center" style="font-size: 14px;">
      <small>Copyright &copy;   Designed by <a href="https://skyislimit.in/" target="_blank" rel="noopener">Skyislimit</a> </small>
    </div>
  </footer>
</body>
  
</html>
