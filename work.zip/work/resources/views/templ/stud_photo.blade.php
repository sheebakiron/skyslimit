@include('templ.header')
<div class="container">
<div  class="col-md-12">
@include('templ.leftmenu')
<form action="photoupdate" method="post" class="form-group"  enctype="multipart/form-data"  >

<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%" >
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%"><h4>Upload Photo</h4></div>
@if(session()->has('messagechphoto'))
    <div class="alert alert-success">
        {{ session()->get('messagechphoto') }}
    </div>
@endif  
<div  class="col-md-9 row" >
      <div  class="col-md-3 form-group">Upload Photo </div>
      <div class="col-md-9 form-group"><input type="file" name="photo" /></div> 
	   <div  class="col-md-3 form-group">&nbsp; </div>
	    @foreach ($users as $user)
      <div class="col-md-9 form-group"><img src="uploads/{{ $user->photo }}" width="100" height="100" /></div> 
       @endforeach
      <div class="col-md-12 form-group">
    <button type="submit"  value = "Add student" class="btn btn-primary">Submit</button>
	</div></div>
</div>
</form>
</div>
</div>
@include('templ.footer')

 