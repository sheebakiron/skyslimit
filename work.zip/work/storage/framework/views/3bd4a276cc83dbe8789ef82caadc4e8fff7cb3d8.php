<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2 class="text-center">SignIn</h2>
  <br> 
   <form action = "customLogin" method = "post" class="form-group" style="width:70%; margin-left:15%;" action="/action_page.php">
  <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
 <?php if(isset($msg)){echo '<label class="form-group" style="color:red;">'.$msg.'</label><br>';}?>
  <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>"><input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
 	<label>Email:</label>
    <input type="email" class="form-control" placeholder="Enter Email"   name="email" required>
	<label>Password:</label>
    <input type="password" class="form-control" placeholder="Enter password" name="password"   required>
     
<br>
    <button type="submit"  value = "Add student" class="btn btn-primary">Submit</button>
  </form>
</div>

<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>