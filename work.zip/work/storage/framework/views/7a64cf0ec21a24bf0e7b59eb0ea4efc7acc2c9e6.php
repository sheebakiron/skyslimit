<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<?php if(session()->has('message')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>Done !!! </strong><?php echo e(session()->get('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>
<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<div class="col-md-12">
<div class="col-md-6">
    Current DateTime :  <?php 
    date_default_timezone_set("Asia/Calcutta");
    echo date("Y-m-d H:i:s");?>
<h1>TODO</h1>

<form method="POST" action=<?php echo e(url('/addtask')); ?>>
<?php echo e(csrf_field()); ?>

<div class="form-group">
<div class="col-md-6">
<label class="form-group">Task:</label>
<input type="text" class="form-control" name="task" placeholder="Enter Task">
</div>
<div class="col-md-6">
<label class="form-group">Start Time:</label>
<input type="datetime-local"   name="start_time" class="form-control" >
</div>
<div class="col-md-6">
<label class="form-group">End Time:</label>
<input type="datetime-local"   name="end_time"  class="form-control">
</div>
<div class="col-md-6">
<br>
<button type="submit" class="btn btn-success">Add</button>
</div>
</div>
 
</form>
</div></div>
<div class="col-md-12" style="border-bottom:1px solid #ccc;">&nbsp;</div>
<div class="col-md-12 row">
 <h4  style="background-color:#cccccc;padding:5px; ">Tasks</h4>
 <div class="col-md-12" style="background-color:#e7e7e7; ">
 <div class="col-md-3 form-group"><b>Task</b></div>
<div class="col-md-2 form-group"><b>Starting Time</b></div>
<div class="col-md-2 form-group"><b>Ending Time</b></div>
<div class="col-md-2 form-group"><b>Status</b></div>
<div class="col-md-3 form-group"> <b>Option</b></div>
</div>
<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$curDateTime = date("Y-m-d H:i:s");
$stDate = date("Y-m-d H:i:s", strtotime($task->start_time));
$enDate = date("Y-m-d H:i:s", strtotime($task->end_time));

if($stDate < $curDateTime)
{
     if($enDate > $curDateTime)
     {
     $timeflag='1';
	 $highlite='style="background-color:#cef436;margin-bottom:2px;"';
	 }
	 else
	 {
	 $timeflag='2';
	 $highlite='style="background-color:#f44336;margin-bottom:2px;"';
	 }
}
else
{
     $timeflag='0';
	 $highlite='style="margin-bottom:2px;border:1px solid #ccc"';
}
?>
<div class="col-md-12" <?php echo $highlite;?>>
<div class="col-md-3 form-group"><?php echo e($task->task); ?>  </div>
<div class="col-md-2 form-group"><?php echo e(date("m/d/Y H:i:s",strtotime($task->start_time))); ?></div>
<div class="col-md-2 form-group"><?php echo e(date("m/d/Y H:i:s",strtotime($task->end_time))); ?></div>
<div class="col-md-2 form-group">
<?php if($timeflag==2){?><span class="glyphicon glyphicon-lock" title="Past due  time">PastDueTime</span><?php }?>
<?php if($timeflag==1){?><span class="glyphicon glyphicon-ok" title="Current Task">Current Task</span><?php }?>
 
</div>
<div class="col-md-3 form-group" style="color:#000;"> <a style="color:#000;" href =<?php echo e(url('/'.$task->id.'/'.$timeflag.'/complete')); ?> >Add To Complete</a></div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
 <div class="col-md-12 row">
  
<h4  style="background-color:#cccccc;padding:5px; ">Completed Tasks</h4>
<div class="col-md-12" style="background-color:#e7e7e7; ">
  <div class="col-md-3 form-group"><b>Task</b></div>
<div class="col-md-2 form-group"><b>Starting Time</b></div>
<div class="col-md-2 form-group"><b>Ending Time</b></div>
<div class="col-md-2 form-group"><b>Status</b></div>
<div class="col-md-3 form-group"> <b>Option</b></div>
</div>
 <?php $__currentLoopData = $completed_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
  $timeflag1=$c_task->timeout;
 if($timeflag1==2)
{
     $highlite1='style="background-color:#f44336;margin-bottom:2px;"';
	 
}
else
{
 	 $highlite1=''; 
}
?>
<div class="col-md-12" <?php echo $highlite1;?>>
<div class="col-md-3 form-group"><?php echo e($c_task->task); ?></div>
<div class="col-md-2 form-group"><?php echo e(date("m/d/Y H:i:s",strtotime($c_task->start_time))); ?></div>
<div class="col-md-2 form-group"><?php echo e(date("m/d/Y H:i:s",strtotime($c_task->end_time))); ?></div>

<div class="col-md-2 form-group"><?php  if($timeflag1==2){?> <span class="glyphicon glyphicon-lock" title="Past due  time">PastDueTime</span> <?php }else{echo '';}?></div>
<div class="col-md-3 form-group"><a style="color:#000;" href =<?php echo e(url('/'.$c_task->id.'/delete')); ?>>Delete</a></div> 
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
 <?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>