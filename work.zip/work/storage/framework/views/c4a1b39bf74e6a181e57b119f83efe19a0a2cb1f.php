<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<div  class="col-md-12">
<?php echo $__env->make('templ.leftmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form action="photoupdate" method="post" class="form-group"  enctype="multipart/form-data"  >

<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%" >
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%"><h4>Upload Photo</h4></div>
<?php if(session()->has('messagechphoto')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('messagechphoto')); ?>

    </div>
<?php endif; ?>  
<div  class="col-md-9 row" >
      <div  class="col-md-3 form-group">Upload Photo </div>
      <div class="col-md-9 form-group"><input type="file" name="photo" /></div> 
	   <div  class="col-md-3 form-group">&nbsp; </div>
	    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-9 form-group"><img src="uploads/<?php echo e($user->photo); ?>" width="100" height="100" /></div> 
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-12 form-group">
    <button type="submit"  value = "Add student" class="btn btn-primary">Submit</button>
	</div></div>
</div>
</form>
</div>
</div>
<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 