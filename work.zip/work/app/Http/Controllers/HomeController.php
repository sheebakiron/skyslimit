<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Hash;
use DB;
use Session;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;


class HomeController extends Controller
{
  
    //
	 public function index()
	    {
		//$urlval='https://www.reddit.com/r/webdev.json';
		     $data = json_decode(file_get_contents("https://www.reddit.com/r/webdev.json?sort=new&limit=5"), true);
             return view('templ.home',['data'=>$data]);
        }
		 public function indexajax($page)
	    {
		//$urlval='https://www.reddit.com/r/webdev.json';
		       $limitv=$page*5;
		       $data = json_decode(file_get_contents("https://www.reddit.com/r/webdev.json?sort=new&limit=".$limitv), true);
			  // return view('templ.homeajax',['data'=>$data]);
			  // $html = view('templ.homeajax', compact('data'))->render();
               //return $html;
			   
			   $html='<input type="hidden" value="'.($page+1).'" >';
			   $klmt=($limitv-4);
			  // $i=(($page-1)*20)+3;if($page==2){$i=(($page-1)*5)+2;}
			  $i=$klmt+1;
			   $k=1;
			   foreach ($data['data']['children'] as $val) 
			   {
			    if($k>$klmt){
						$title = $val['data']['title'];
						$domain = $val['data']['domain'];
						$selftext = $val['data']['selftext'];
						$url = $val['data']['url'];
						$post_id = $val['data']['id'];
						$date = $val['data']['created_utc'];
						$user = $val['data']['author'];
						$img = $val['data']['thumbnail'];
						if (@getimagesize($img)) {
						$imflag=1;
						} else {
						$imflag=2;
						}
						$html.='<div class="card mb-3">
			<div class="card-body">
			  <h5 class="card-title">'.$i.')   '.$title.' </h5>';
			   
			  if($imflag==1){ 
				  $html.=' <p>
				   <img title="'.$user.'" class="img-responsive   blog-inner" src="'.$img.'">
				   </p>';
					 } 
			 $html.=' <p class="card-text"><b>'.$user.', '.date("M d , Y",$date).'</b>';
				 if(strlen($selftext)>5){ 
				 $pstid="'".$post_id."'";
					 $html.='  --<span id="icon'.$post_id.'" > '.substr($selftext,0,25).'
					   ...(<a onClick="popin('.$pstid.')" style="color:#FF0000;cursor:pointer;">More</a>)
					  </span>
					  <span id="info'.$post_id.'" style="display: none" >'.$selftext.'
					  <br><a onClick="popout('.$pstid.')" style="color:#FF0000;cursor:pointer;">Less</a>
					  </span>';
					   } 
			 $html.=' </p>
			</div>
		  </div>';
		  $i++;
		  }
		  $k++;
	   
			  }
			 // $html.=' <div class="card mb-3 loadid" >Loading...</div>';
			  echo $html;
			  exit;
        }
        public function register()
	    {
             return view('templ.stud_create');	
        }
       
	     public function insert(Request $request)
		{  
			$password = Input::get('password');
            $email = Input::get('email');
            $rules = array('email' => 'unique:users,email','password' => 'required|string|min:8');
            $input['email'] = $email;$input['password'] = $password;
			$validator = Validator::make($input, $rules);
			$emailflag=0;
			$pss=Hash::make($password);
			$data = $request->all();
			$data['password']=$pss;
			unset($data['_token']);
			if ($validator->fails())
			{ 
			     $postdata['data'][]=$data; 
				 $postdata['msg']='Duplicate entry for email or minimum length for password is 8 with alphanumeric characters!!';
				 return view('templ.stud_create')->with($postdata);	
			}else{
				 $check = $this->create($data);
				 Session::flash('message','You have successfully Registered! Pls login to view your account');
				 return redirect("login");
				
			}
		}
		 public function create(array $data)
			{
			DB::table('users')->insert($data);
			}
		public function view()
	    {
		     $id=Auth::id();
			 if($id>0){
 			 $users = DB::select('select * from users where id='.$id);
             return view('templ.stud_view',['users'=>$users]);
			 }else{return redirect("login");}
        }    
		public function login() {
               return view('templ.stud_login');
        }
		public function customLogin(Request $request)
		{
			 
	   
			$credentials = $request->only('email', 'password');
			if (Auth::attempt($credentials)) {
				return redirect()->intended('profile')
							->withSuccess('Signed in');
			}
			Session::flash('message','Login details are not valid');
				 return redirect("login");
	  
			//return redirect("login")->withSuccess('Login details are not valid');
		}
		 
		public function signout(Request $request) {
		  Auth::logout();
		  return redirect('/login');
		}
		public function upload(Request $request) {
		   $id=Auth::id();
			 if($id>0){ 
			 $users = DB::select('select photo from users where id='.$id);
             return view('templ.stud_photo',['users'=>$users]);
			 }else{return redirect("login");}
		}
		public function changepass(Request $request) {
		     $id=Auth::id();
			 if($id>0){ 
			 $users = DB::select('select photo from users where id='.$id);
             return view('templ.stud_password',['users'=>$users]);
			 }else{return redirect("login");}
		}
		public function passupdate(Request $request) {
		    $id=Auth::id();
			$password = $request->input('password');
			$pss=Hash::make($password);
			DB::update('update users set password = ? where id = ?',[$pss,$id]);
			Session::flash('messagechpass','You have successfully updated password!');
			return redirect("changepass");
		} 
		public function photoupdate(Request $request) {
		    $id=Auth::id();
			//$photo = $request->input('photo');
			//------------------upoload file----------------------//
 			$file = $request->file('photo');
			$ext=$file->getClientOriginalExtension();
			//Move Uploaded File
			$destinationPath = 'uploads';
			if ($ext !== 'gif' && $ext !== 'png' && $ext !== 'jpg' && $ext !== 'jpeg' && $ext !== 'JPG' && $ext !== 'JPEG' && $ext !== 'GIF') 
			{$mssg='pls upload jpg or png or gif files!';}else{
			$file->move($destinationPath,$file->getClientOriginalName());
			$photo=$file->getClientOriginalName();
 			///----------------------------------------------------//
			DB::update('update users set photo = ? where id = ?',[$photo,$id]);
			$mssg='You have successfully updated photo!';
			} 
			 Session::flash('messagechphoto',$mssg);
			 return redirect("upload");
		} 
 
 }