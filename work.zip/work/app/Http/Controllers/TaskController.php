<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session;
use App\Task;

class TaskController extends Controller
{
public function index(){
$tasks = Task::where("iscompleted", false)->orderBy("id", "DEC")->get();
$completed_tasks = Task::where("iscompleted", true)->orderBy("id", "DEC")->get();
return view("templ.todo", compact("tasks", "completed_tasks"));
}
public function store(Request $request)
{
$input = $request->all();
/*$task = new Task();
$task->task = request("task");
$task->save();*/
$data['task']=request("task");
$dstart_time=request("start_time");
$dend_time=request("end_time");
$data['start_time']=date("Y-m-d H:i:s",strtotime($dstart_time)); 
$data['end_time']=date("Y-m-d H:i:s",strtotime($dend_time));
DB::table('tasks')->insert($data);
Session::flash('message','Task has been added!');
return Redirect::back();
}
public function complete($id,$timeflag)
{
//$task = Task::find($id);
$iscompleted = true;
$data['iscompleted']=$iscompleted;
$data['timeout']=$timeflag;
 
//DB::table('tasks')->update($data);
DB::table('tasks')
              ->where('id', $id)
              ->update($data);
//$task->save();
Session::flash('message','Task has been added to completed list!');
return Redirect::back();
}
public function destroy($id)
{
$task = Task::find($id);
$task->delete();
return Redirect::back()->with('message', "Task has been deleted");
}
}